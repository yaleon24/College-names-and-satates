#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

ifstream infile;
vector<string>college;
vector <string>state;
//////////////////////////reading from files///////////
int schoolfiles()
{
   string lane;
    infile.open("colleges.txt");
   if(!infile)
    {
        cout<<"Error opening file colleges.txt"<<endl;
        return -1;
    }
    while (getline(infile, lane))
    {
        college.push_back(lane);
    }
    infile.close();
    /////////////////////////////////////////////////////////////////
     infile.open("states.txt");
     
   if(!infile)
    {
        cout<<"Error opening file states.txt"<<endl;

        return -1;
    }
    while (getline(infile, lane))
    {
        state.push_back(lane);
    }
return 1;
}

/////////////////////////choice1////////////////////////////////////////////
bool atschoolvector(string c){             //is college present
   for(int i=0;i<college.size();i++){
       if(c.compare(college[i])==0){
           return true;
       }
   }
   return false;
}

//////////////////////////choice 2///////////////////////////////////////////////////
int totalschools(string st){         //get number of colleges in state
   int c=0;
   for(int k=0;k<state.size();k++){
       if(st.compare(state[k])==0){
           c++;
       }
   }
   return c;
}

/////////////////////////choice 3////////////////////////////////////////////////////////////
int totaluniversity(){             //get total of colleges
   int c=0;
   for(int i=0;i<state.size();i++){
       c++;
   }
   return c;
   
}

int main(){
   int choice;
   string schoolname;
   string regionname;
   
   if(schoolfiles() == -1){
       return -1;
   }
  
   while(1){
       cout<<"WELCOME TO MY COLLEGE AND UNIVERSITY SUMMARY PROGRAM."<<endl;
       cout<<"Press 1 to enter possible colleges and universities and the program will tell you if they appear on the list."<<endl;
       cout<<"Press 2 to find out how many colleges and universities appear in the state of your choice."<<endl;
       cout<<"Press 3 to find out how many colleges and universities appear on our list in total."<<endl;
       cout<<"Press 4 to quit."<<endl;
       cin>>choice;
          if (choice==1){ 
           cout <<"Please enter a college name: " << endl;
           cin.ignore();
          getline(cin,schoolname);
                   if(atschoolvector(schoolname)){
                      cout <<"This college is in our database." << "\n";
                   }
                   else{
                      cout << "This university is not in our database." << "\n";
                   }
                   
               }
           ////////////////////////////////choice 2//
           else if(choice==2){
		           cout << "Which state do you want a college count for?: " << endl;
                   cin>>regionname;
                   if(totalschools(regionname)){
                   cout<<"There are "<<totalschools(regionname)<< " colleges in "<< regionname<<"."<<"\n";
                   } else{
                   cout <<"This is not a valid state." << "\n\n";
                   }
                   
               }
           /////////////////////////////////choice 3/////////
           else if(choice==3){
            cout<<"There are "<<totaluniversity()<< " colleges and universities in our database."<< "\n";
            
                             }
           //////////////////////////////////choice 4////////                  
           else if(choice==4){
		   
            return 0;
               break;
           }
       };
       cin.clear();
       fflush(stdin);
       cout<<endl;
   }

